import java.util.Scanner;
class multiple{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the number1");
        double n1=sc.nextInt();
        System.out.println("enter the number2");
        double n2=sc.nextInt();
        double n3=n1*n2;
        System.out.println(" the factorial of " + n1 + n2+ " is "+n3);
    }
}
