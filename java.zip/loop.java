package demo.loop;

public class opendoor{
    public static void main(string[]args){
        int doorcode=1234;
        if doorcode==1234;
        System.out.println(x:"correct code.the door will be opened")
    }
}