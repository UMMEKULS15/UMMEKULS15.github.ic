public class factorial{
    public static void main(String[] args){
        System.out.println("enter the number1");
        double n1=scanner.nextInt();
        System.out.println("enter the number2");
        double n2=scanner.nextInt();
        int factorial=1;
        for(i=1;i<=n;i++){
        multiple=n1*n2;
        }
        System.out.println(" the multiple of " + n + " is "+ multiple);
    }
}



