
 class hello {

	public static void main(String[] args) {
		System.out.println("java project");
		System.out.println("umme kulsum");
		System.out.println("1sv22cs117");
		System.out.println("3rd year");
	}
 }