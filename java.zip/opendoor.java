import java.util.Scanner;

public class opendoor{
    public static void main(String[] args){
        int choice=1;
        switch(choice){
        case 1:
            System.out.println("monday:i need coffee day...");
        case 2:
            System.out.println("tuseday:i need a break...");
        case 3:
            System.out.println("wednesday:i want to go banglore...");
            break;
         case 4:
            System.out.println("thursday: i need a tea day...");
            break;
         case 5:
            System.out.println("friday:good friday..");
            break;
        case 6:
            System.out.println("saturday:universal day");
            break;
        case 7:
            System.out.println("sunday:holiday");
            break;
            default:
                System.out.println("invalid choice");
                break;
        }
    }
}


        