
class Animal{
    public void sound(){
        System.out.println("animal make sound");
}
}
class dog extends Animal{
    //subclass method override the super class method
    public void sound(){
    System.out.println("the dog can barks");
}
}
class cat extends Animal{
    //subclass method override thesuper class method
    public void sound(){
        System.out.println("the cat moves");
    }
}
public class Override{
    public static void main(String[] args){
    Animal myAnimal= new Animal();
    Animal mydog= new dog();
    Animal mycat= new cat();

    myAnimal.sound();
    mydog.sound();
    mycat.sound();
}
}

