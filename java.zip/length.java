import java.util.Scanner;

class length{
    public static void main(String[]args){
    Scanner sc=new Scanner(System.in);
    System.out.println("enter the character");
    String cr = sc.next();
    
    int length = cr.length();
    System.out.println("the length of the character is" +length);
}
}