public class Car{
    String brand;
    int year;

    public Car(String brand,int year){
        this.brand=brand;
        this.year=year;
    }
    public void displaycarinfo(){
        System.out.println("car brand"+ brand);
        System.out.println("manufacturyear"+year);
    }
    public static void main(String[]args){
        Car mycar=new Car("BMW",1995);
        mycar.displaycarinfo();
    }
}


