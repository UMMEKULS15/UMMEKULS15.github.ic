import java.util.Scanner;
class palindrome{
    public static void main(String[] args){
        int n,t,rem,r=0;
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the number");
        n=sc.nextInt();
        t=n;
        while(t>0){
            rem=t%10;
            r=r*10+rem;
            t=t/10;
        System.out.println("enter the number is"+r);
        if(n==r){
        System.out.println("the number is palindrome");
        }
        else{
         System.out.println("the number is not a palindrome");
        }
        }
        }
    }

