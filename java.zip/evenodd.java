import java.util.Scanner;
public class greatest{
    public static void main(String[]args){
        Scanner scanner=new Scanner(System.in);
        System.out.println("enter the number1");
         System.out.println("enter the number2");
        int n1=Scanner.nextInt();
        int n2=Scanner.nextInt();
        if(n%2==0){
        System.out.println("given number is greater than n2");
        }
        
        else{
        System.out.println("given number is smaller than n2");
    }
    }
}