class Bird{
    void fly(){
        System.out.println("bird can fly");

    }
}
    class Parrot extends Bird{
        void color(){
            System.out.println("i am green");

        }

    }
    class cow extends Bird{
        void whatcoloriam(){
            System.out.println("i am black");
        }
    }
public class main
{
public static void main(String[] args){
    Parrot p=new Parrot();
    cow s=new cow();
    s.whatcoloriam();
    p.color();
    p.fly();
}
}
package demo;
public class hybridInheritance{
    public static void main(string[] args){
        D obj=new D();
        obj.display();
        }
        }
    //super class
class A{
    int a=1;

    }
    class B extends A{
        int b=2;
    }
    //interface
    interface c{
        int c=3;
    }
    //extend and implementation together
    class D extends B implements c{
        int d=4;
        int sum=a+b+c+d;
       public void display();
       System.out.println("the value of a is "+a);
       System.out.println("the value of a is "+b);
       System.out.println("the value of a is "+c);
       System.out.println("the value of a is "+d);
       System.out.println("the sum is"+sum);
    }
    

    

    

    

    

    }