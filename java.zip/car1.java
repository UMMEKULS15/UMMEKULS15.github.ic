class car1 {
    private String modelname;
    private String owner;
    private int regnumber;

public car1(String modelname,String owner,int regnumber){
    this.modelname=modelname;
    this.owner=owner;
    this.regnumber=regnumber;
}
public void startengine(){
    System.out.println("car can be started");
}
public void accelerate(){
    System.out.println("car can be accelerated");
}
    public void stop(){
        System.out.println("car can be stoped");
    }
    public void showcarinfermation(){
        System.out.println("car can be ownered by"+owner);
        System.out.println("car model is"+modelname);
        System.out.println("the regnumber is"+regnumber);       
    }
    public static void main(String[]args){
        car1 mycar=new car1("suzuki","xyz",1234);
        mycar.startengine();
        mycar.accelerate();
        mycar.stop();
        mycar.showcarinfermation();
    }
   }
