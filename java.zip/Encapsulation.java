class Person{
    private String name;
    private int Age;
    //getter method for name
public String getName(){
    return name;
    }
    //setter method for name
    public void setName(String name){
        //we can add validation here if needs
        if(name !=null && name.isEmpty()){
        System.out.println("Invalid name:" + name); 
    }
    else{
         this.name = name;
    }
        
}
    public int getAge(){
        return Age;
    }
    public void setAge(int age){
    if(Age > 0){
        System.out.println("Invalid age:" + age);
            
        }
    else{
        this.Age=age;
            
    }
}
}
public class Encapsulation{
    public static void main(String[]args){
        Person Person=new Person();
        Person.setName("umme");
        Person.setAge(19);

        System.out.println("name:"+Person.getName());
        System.out.println("age:"+Person.getAge());
    }
}


    
    
    

