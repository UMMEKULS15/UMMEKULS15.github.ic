import java.util.Scanner; 
class calculater{
    public static void main(String[]args){
        Scanner sc=new Scanner(System.in);
        int a,b,result;
        System.out.println("please enter any two number=");
    a=sc.nextInt();
    b=sc.nextInt();
    System.out.println("enter your choice");
    int operator=sc.nextInt();
    switch(operator)
    {
    case 1:
        result=a+b;
        System.out.println("result:" + result);
        break;
    case 2:
         result=a-b;
         System.out.println("result:" + result);
         break;
    case 3:
        result=a*b;
        System.out.println("result:" + result);
        break;
    case 4:
         result=a/b;
         System.out.println("you have entered incorrect option");
        break;
        default:
    System.out.println("invalid choice");
    }
    }
}
