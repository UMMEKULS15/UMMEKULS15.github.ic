import java.util.Scanner;
class reverseString{
    public static void main(String[] args){
     Scanner sc=new Scanner(System.in);
        System.out.println("enter a string");
        String input=sc.nextLine();
        String reverse=" ";
        for(int i=input.length()-1;i>=0;i--){
            reverse+=input.charAt(i);

        }
        System.out.println("the reverseString is"+reverse);
    }
}

    

        

