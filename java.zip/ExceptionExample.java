public class ExceptionExample{
    public static void main(String[]args){
        try{
            int a=10/0;
            System.out.println("result:"+a);
        }
        catch(ArithmeticException e){
            System.out.println("error diviation by zero");
        }finally{
            System.out.println("this is finally block");
        }
        System.out.println("rest of the code....!");
        }
    }
