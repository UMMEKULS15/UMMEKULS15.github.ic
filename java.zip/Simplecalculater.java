import java.util.Scanner;
class SimpleCalculater{
    public static void main(String[] args){
        int p,t,r,result;
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the number1");
        p=sc.nextInt();
        System.out.println("enter the number2");
         t=sc.nextInt();
        System.out.println("enter the number2");
        r=sc.nextInt();
        result=(p*t*r)/100;
        System.out.println("the simple interest of calculater is"+result);
    }
}