import java.util.Scanner;
public class greatest{
    public static void main(String[]args){
        Scanner scanner=new Scanner(System.in);
        System.out.println("enter the number1");
        int n1=scanner.nextInt();
        System.out.println("enter the number2");
        int n2=scanner.nextInt();
        System.out.println("enter the number3");
        int n3=scanner.nextInt();
        if(n1>n2 && n1>n3 ){
        System.out.println("given number is greater than n2 and n3");
        }
        
        else if(n2>n1 && n2>n3){
        System.out.println("given number is smaller than n1 and n3");
        }
        else
        {
         System.out.println("given number is smaller than n1 and n2");   
        }

    }
}