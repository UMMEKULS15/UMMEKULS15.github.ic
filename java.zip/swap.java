import java.util.Scanner;
class Swap{
    public static void main(String[] args){
        int a,b,temp;
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the number1");
        a=sc.nextInt();
        System.out.println("enter the number2");
         b=sc.nextInt();
        temp=a;
        a=b;
        b=temp;
        System.out.println("after swapping");
        System.out.println("a:"+a);
        System.out.println("b"+b);

    }
}